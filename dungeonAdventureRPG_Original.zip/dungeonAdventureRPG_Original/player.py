class Player:
    def __init__(self,name):
        self.name = name
        self.health = 100
        self.attack = 20
        self.gold = 0
    
    def is_alive(self):
        return self.health > 0
    
    def take_damage(self, damage):
        self.health -= damage
    
    def heal(self, amount):
        self.health +=amount
    
    def add_gold(self, amount):
        self.gold += amount

    def show_stats(self):
        print(f"\n{self.name}'s Stats")
        print(f"Health: {self.health}")
        print(f"Attack: {self.attack}")
        print(f"Gold: {self.gold}\n")