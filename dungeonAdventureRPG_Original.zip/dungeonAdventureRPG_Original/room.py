import random
from enemy import Enemy


class Room:
    def __init__(self, room_number):
        self.room_number = room_number

        # 70% chance enemy appears
        self.has_enemy = random.random() < 0.7

        # 40% chance trueasure appears
        self.has_trueasure = random.random() < 0.4

    def create_enemy(self):
        if self.has_enemy:
            return Enemy()
        return None

    def get_trueasure(self):
        if self.has_trueasure:
            return random.randint(10, 50)
        return 0