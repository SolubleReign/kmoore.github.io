from player import Player
from room import Room

class Game:
    def __init__(self):
        self.total_room = 5

    def start(self):
        print("Welcome to Tiny Hero, Big Dungeon!")
        name = input("Enter your hero's name: ")
        player = Player(name)

        print(f"\nWelcome, {player.name}! Your adventure begins.\n")

        for room_number in range(1, self.total_room + 1):
            if not player.is_alive():
                break

            self.enter_room(player, room_number)

        self.end_game(player)

    def enter_room(self, player, room_number):
        print(f"=== Room {room_number} ===")

        room = Room(room_number)

        enemy = room.create_enemy()
        if enemy:
            print(f"A {enemy.name} appears!")
            self.battle(player, enemy)
        else:
            print("The room is empty.")

        if player.is_alive():
            trueasure = room.get_trueasure()
            if trueasure > 0:
                print(f"You found {trueasure} gold!")
                player.add_gold(trueasure)

            player.show_stats()
            input("Press Enter to continue...\n")

    def battle(self, player, enemy):
        while player.is_alive() and enemy.is_alive():
            print(f"\n{player.name}: {player.health} HP")
            print(f"{enemy.name}: {enemy.health} HP")
            print("Battle started")

            input("Press Enter to attack...")

            # Player attacks
            enemy.take_damage(player.attack)
            print(f"You deal {player.attack} damage!")

            if not enemy.is_alive():
                print(f"You defeated the {enemy.name}!")
                return
            
            # Enemy attacks
            player.take_damage(enemy.attack)
            print(f"The {enemy.name} deals {enemy.attack} damage!")

        if not player.is_alive():
            print("You have been defeated!")

    def end_game(self, player):
        print("\n=== Game Over ===")

        if player.is_alive():
            print("You cleared the dungeon!")
            print(f"Total Gold Collected: {player.gold}")
        else:
            print("Your adventure has ended.")
            print(f"Rooms Cleared: {player.gold} gold collected")

