import random


class Enemy:
    def __init__(self):
        enemy_types = [
            ("Goblin", 30, 10),
            ("Skeleton", 40, 12),
            ("Orc", 50, 15)
        ]

        name, health, attack = random.choice(enemy_types)

        self.name = name
        self.health = health
        self.attack = attack

    def is_alive(self):
        return self.health > 0

    def take_damage(self, damage):
        self.health -= damage