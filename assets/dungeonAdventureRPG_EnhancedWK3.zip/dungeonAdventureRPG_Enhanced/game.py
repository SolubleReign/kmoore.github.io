
# Game controller for Tiny Hero, Big Dungeon.


from player import Player
from room import Room


class Game:

    # Main game controller.
    

    def __init__(self):
        self.player = None
        self.current_room = 1
        self.max_rooms = 5

    def get_player_name(self):
        
        # Prompt the user for a valid player name.
        
        while True:
            name = input("Enter your hero's name: ").strip()

            if name:
                return name

            print("Name cannot be empty. Please try again.")

    def wait_for_attack(self):
    
    # Require the player to press only the Enter key before attacking.
    
        while True:
            user_input = input("Press Enter to attack...")

            # If the user presses Enter without typing anything,
            # input() returns an empty string.
            if user_input == "":
                return

        print("Invalid input. Just press Enter to attack.")

    def start(self):
       
        # Start the game.
        
        print("Welcome to Tiny Hero, Big Dungeon!")

        player_name = self.get_player_name()
        self.player = Player(player_name)

        while self.player.is_alive() and self.current_room <= self.max_rooms:
            print(f"\n--- Room {self.current_room} ---")

            room = Room(self.current_room)
            self.enter_room(room)

            if self.player.is_alive():
                self.current_room += 1

        self.end_game()

    def enter_room(self, room):
        # Handle everything that happens inside a room.
        
        # Create an enemy if one appears.
        enemy = room.create_enemy()

        if enemy:
            print(f"A {enemy.name} appears!")
            self.battle(enemy)
        else:
            print("The room is empty.")

        # Award treasure if the player survives.
        if self.player.is_alive():
            # Make sure room.py contains a method named get_treasure().
            gold_found = room.get_treasure()

            if gold_found > 0:
                print(f"You found {gold_found} gold!")
                self.player.add_gold(gold_found)

        # Show updated player stats.
        self.player.show_stats()
    
    # Handle turn-based combat.

    def battle(self, enemy):
        print(f"\nBattle Start! You are fighting a {enemy.name}.")

        while self.player.is_alive() and enemy.is_alive():
            #Pause before each round.
            input(f"\nPress Enter to attack...")

            # Player attacks.
            print(f"\nYou attack the {enemy.name} for {self.player.attack} damage.")
            enemy.take_damage(self.player.attack)

            # Displays enemy health immediatly after the player's attack.
            print(f"{enemy.name} Health: {enemy.health}")

            #If the enemy was defeated. end the battle loop.
            if not enemy.is_alive():
                break

            # Pause so the player can read the enemy's reamaining health.
            input("Press Enter to continue...") 

            #Enemy attacks
            print(f"The {enemy.name} attacks you for {enemy.attack} damage.")
            self.player.take_damage(enemy.attack)

            # Display player health after taking damage.
            print(f"{self.player.name} Health: {self.player.health}")

            # Pause so the player can read their updated health.
            if self.player.is_alive():
                input("Press Enter for the next round...")
            
        # Display battle result.
        if self.player.is_alive():
            print(f"\nYou defeated the {enemy.name}!")
        else:
            print("\nYou were defeated!")  

    def end_game(self):
        
        # Display the final game result.
        
        print("\n=== Game Over ===")

        if self.player.is_alive():
            print("Congratulations! You cleared the dungeon!")
        else:
            print("Your adventure has come to an end.")

        self.player.show_stats()