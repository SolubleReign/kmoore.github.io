
# Player class for Tiny Hero, Big Dungeon.



class Player:
    
    # Represents the player character.
   

    def __init__(self, name):
        self.name = name
        self.health = 100
        self.attack = 20
        self.gold = 0

    def is_alive(self):
        
    # Returns True if the player is still alive.
       
        return self.health > 0

    def take_damage(self, damage):
      
    # Reduces the player's health.
       
        self.health -= damage

    # Prevent health from dropping below zero.
        if self.health < 0:
            self.health = 0

    def heal(self, amount):
        
    # Restores health to the player.
        
        self.health += amount

    def add_gold(self, amount):
        
    # Adds gold to the player's inventory.
        
        self.gold += amount

    def show_stats(self):
        
    # Displays current player statistics.
        
        print(f"\n{self.name}'s Stats")
        print(f"Health: {self.health}")
        print(f"Attack: {self.attack}")
        print(f"Gold: {self.gold}\n")