# Enemy class for Tiny Hero, Big Dungeon.

import random


class Enemy:
    
    # Represents a random enemy
    
    def __init__(self):
        enemy_types = [
            ("Goblin", 30, 10),
            ("Skeleton", 40, 12),
            ("Orc", 50, 15)
        ]

        name, health, attack = random.choice(enemy_types)

        self.name = name
        self.health = health
        self.attack = attack

    def is_alive(self):

        # Returns True if the enemy is still alive.

        return self.health > 0

    def take_damage(self, damage):

        # Reduced the enemy's health. 

        self.health -= damage

        if self.health < 0:
            self.health = 0