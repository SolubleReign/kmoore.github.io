# Game controller for Tiny Hero, Big Dungeon.

import logging
import logging

from player import Player
from room import Room
from enemy_journal import EnemyJournal

# Configure logging
logging.basicConfig(
    filename="game.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


class Game:

    def __init__(self):
        self.player = None
        self.current_room = 1
        self.max_rooms = 5

        self.journal = EnemyJournal()

    def get_player_name(self):

        while True:

            try:
                name = input("Enter your hero's name: ").strip()

                if not name:
                    raise ValueError(
                        "Name cannot be empty. Please try again."
                    )

                return name

            except ValueError as error:
                print(error)

    def start(self):

        print("Welcome to Tiny Hero, Big Dungeon!")

        player_name = self.get_player_name()

        self.player = Player(player_name)

        logging.info(f"Game started for player: {player_name}")

        while (
            self.player.is_alive()
            and self.current_room <= self.max_rooms
        ):

            print(f"\n--- Room {self.current_room} ---")

            room = Room(self.current_room)

            self.enter_room(room)

            if self.player.is_alive():
                self.current_room += 1

        self.end_game()

    def enter_room(self, room):

        enemy = room.create_enemy()

        if enemy:

            print(f"\nA {enemy.name} appears!")

            logging.info(
                f"Enemy encountered: {enemy.name}"
            )

            input("\nPress Enter to begin battle...")

            self.battle(enemy)

        else:
            print("\nThe room is empty.")

        # Treasure
        if self.player.is_alive():

            gold_found = room.get_treasure()

            if gold_found > 0:

                print(f"\nYou found {gold_found} gold!")

                self.player.add_gold(gold_found)

                logging.info(
                    f"Player found {gold_found} gold"
                )

        self.player.show_stats()

    def battle(self, enemy):

        print(
            f"\nBattle Start! "
            f"You are fighting a {enemy.name}."
        )

        while (
            self.player.is_alive()
            and enemy.is_alive()
        ):

            # PLAYER TURN
            input("\nPress Enter to attack...")

            print(
                f"\nYou attack the "
                f"{enemy.name} for "
                f"{self.player.attack} damage."
            )

            enemy.take_damage(self.player.attack)

            print(
                f"{enemy.name} Health: "
                f"{enemy.health}"
            )

            logging.info(
                f"{self.player.name} attacked "
                f"{enemy.name} for "
                f"{self.player.attack} damage"
            )

            # Enemy defeated
            if not enemy.is_alive():

                self.journal.record_enemy(enemy)

                break

            # Pause before enemy turn
            input("\nPress Enter for enemy turn...")

            # ENEMY TURN
            print(
                f"\nThe {enemy.name} attacks "
                f"you for {enemy.attack} damage."
            )

            self.player.take_damage(enemy.attack)

            print(
                f"{self.player.name} Health: "
                f"{self.player.health}"
            )

            logging.info(
                f"{enemy.name} attacked "
                f"{self.player.name} for "
                f"{enemy.attack} damage"
            )

            # Pause before next round
            if (
                self.player.is_alive()
                and enemy.is_alive()
            ):
                input(
                    "\nPress Enter for next round..."
                )

        # END OF BATTLE
        if self.player.is_alive():

            print(
                f"\nYou defeated the {enemy.name}!"
            )

            logging.info(
                f"{enemy.name} defeated"
            )

            input(
                "\nPress Enter to continue..."
            )

        else:

            print("\nYou were defeated!")

            logging.info("Player defeated")

    def end_game(self):

        print("\n=== Game Over ===")

        if self.player.is_alive():
            print(
                "Congratulations! "
                "You cleared the dungeon!"
            )

        else:
            print(
                "Your adventure has come to an end."
            )

        self.player.show_stats()

        self.journal.show_journal()
        
        logging.info("Game ended")