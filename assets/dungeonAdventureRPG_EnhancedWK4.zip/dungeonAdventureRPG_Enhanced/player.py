
# Player class for Tiny Hero, Big Dungeon.

from character import Character

class Player(Character):
    
    # Represents the player character.
   

    def __init__(self, name):
        super().__init__(name, 100, 20)

        self.gold = 0

    def heal(self, amount):
        
    # Restores player health.
       
        self.health += amount
      
    def add_gold(self, amount):

        # Adds gold to player inventory.

        self.gold += amount

    def show_stats(self):
        
    # Displays current player statistics.
        
        print(f"\n{self.name}'s Stats")
        print(f"Health: {self.health}")
        print(f"Attack: {self.attack}")
        print(f"Gold: {self.gold}\n")