# Enemy Journal system for Tiny Hero, Big Dungeon.

class EnemyJournal:

    def __init__(self):

        # Stores enemy records
        self.enemies = {}

    def record_enemy(self, enemy):

        if enemy.name not in self.enemies:

            self.enemies[enemy.name] = {
                "health": enemy.health,
                "attack": enemy.attack,
                "defeated": 1
            }

        else:
            self.enemies[enemy.name]["defeated"] += 1

    def search_enemy(self, name):

        return self.enemies.get(name)

    def sort_by_health(self):

        return sorted(
            self.enemies.items(),
            key=lambda item: item[1]["health"]
        )

    def sort_by_attack(self):

        return sorted(
            self.enemies.items(),
            key=lambda item: item[1]["attack"]
        )

    def show_journal(self):

        print("\n=== Enemy Journal ===")

        if not self.enemies:
            print("No enemies recorded.")
            return

        for name, stats in self.enemies.items():

            print(f"\n{name}")
            print(f"Health: {stats['health']}")
            print(f"Attack: {stats['attack']}")
            print(f"Defeated: {stats['defeated']}")