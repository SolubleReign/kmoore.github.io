# Room class for Tiny Hero, Big Dungeon


import random
from enemy import Enemy


class Room:
    
    # Represents a room in the dungeon
    
    def __init__(self, room_number):
        self.room_number = room_number

        # 70% chance enemy appears
        self.has_enemy = random.random() < 0.7

        # 40% chance treasure appears
        self.has_treasure = random.random() < 0.4

    def create_enemy(self):
        
        # Creates and returns an enemy if one exists in the room.
        
        if self.has_enemy:
            return Enemy()
        return None

    def get_treasure(self):

        # Returns a random amount of gold of treasure exsits.

        if self.has_treasure:
            return random.randint(10, 50)
        return 0