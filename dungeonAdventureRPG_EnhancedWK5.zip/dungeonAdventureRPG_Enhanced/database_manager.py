import sqlite3

class DatabaseManager:

    DATABASE_NAME = "game.db"

    @staticmethod
    def initialize_database():

        connection = sqlite3.connect(
            DatabaseManager.DATABASE_NAME
        )

        cursor = connection.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS players (
                player_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                health INTEGER,
                attack INTEGER,
                gold INTEGER,
                current_room INTEGER
            )
        """)
        connection.commit()
        connection.close()

    @staticmethod
    def save_player(player, current_room):

        connection = sqlite3.connect(
            DatabaseManager.DATABASE_NAME
        )

        cursor = connection.cursor()

        cursor.execute(
            "DELETE FROM players"
        )

        cursor.execute("""
            INSERT INTO players
            (
                name,
                health,
                attack,
                gold,
                current_room
            )
            VALUES (?,?,?,?,?)
            """,
        (
            player.name,
            player.health,
            player.attack,
            player.gold,
            current_room
        ))
            
        connection.commit()
        connection.close()
    
    @staticmethod
    def load_player():
        
        connection = sqlite3.connect(
            DatabaseManager.DATABASE_NAME
        )

        cursor = connection.cursor()

        cursor.execute("""
            SELECT
                name,
                health,
                attack,
                gold,
                current_room
            FROM players
            LIMIT 1
        """)

        result = cursor.fetchone()

        connection.close()

        return result
    
        

        